    <link rel="stylesheet" href="{{ asset('backend/css/font-awesome.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/bootstrap.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/animate.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/waves.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/layout.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/components.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/plugins.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/common-styles.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/pages.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/responsive.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('backend/css/matmix-iconfont.css') }}" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Roboto:400,300,400italic,500,500italic" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet" type="text/css">