@extends('backend.layouts.master')

@section('custom_style')

<style type="text/css">
    .logo-text, .logo-text:hover
    {
        font-size: 35px;
        padding: 6px 6px 3px 6px;
        text-decoration: none;
        color: #000000;
        /* font-weight: bold; */
        font-family: 'times new roman';
    }

    .large-logo-text, .large-logo-text:hover
    {
        font-size: 40px;
        padding: 10px 30px 6px 30px !important;
        text-decoration: none;
        font-family: 'times new roman';
        color: #000000;
    }
</style>

@endsection

@section('main_content')

	<div class="page-breadcrumb">
        <div class="row">
            <div class="col-md-7">
                <div class="page-breadcrumb-wrap">
                    <div class="page-breadcrumb-info">
                        <h2 class="breadcrumb-titles">Mortgage Loan Officer <small> View Details</small></h2>
                        <ul class="list-page-breadcrumb">
                            <li><a href="#">Home</a>
                            </li>
                            <li class="active-page">View Details of Mortgage Loan Officer</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
            </div>
        </div>
    </div>
	<div class="row">
        <div class="col-md-12">
            <div class="box-widget widget-module">
                <div class="widget-head clearfix">
                    <span class="h-icon"><i class="fa fa-slack"></i></span>
                    <h4>View Details</h4>
                </div>
                <div class="widget-container">
                    <div class=" widget-block">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tbody>
                                    <tr>
                                        <th>Full Name</th>
                                        <td>{{ ucfirst($mortgage_details[0]->first_name) }} {{ ucfirst($mortgage_details[0]->last_name) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Address</th>
                                        <td>{{ ucfirst($mortgage_details[0]->address) }}</td>
                                    </tr>
                                    <tr>
                                        <th>City</th>
                                        <td>{{ ucfirst($mortgage_details[0]->first_name) }}</td>
                                    </tr>
                                    <tr>
                                        <th>State</th>
                                        <td>{{ ucfirst($mortgage_details[0]->state) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Zip Code</th>
                                        <td>{{ ucfirst($mortgage_details[0]->zip_code) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Username</th>
                                        <td>{{ ucfirst($mortgage_details[0]->username) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td>{{ ucfirst($mortgage_details[0]->email) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Password</th>
                                        <td><button class="btn btn-info" style="padding: 4px 10px;"> Change Password</button></td>
                                    </tr>
                                    <tr>
                                        <th>Company Name</th>
                                        <td>{{ ucfirst($mortgage_details[0]->company_name) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Experience</th>
                                        <td>{{ ucfirst($mortgage_details[0]->experience) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Telephone No.</th>
                                        <td>{{ ucfirst($mortgage_details[0]->telephone) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Mobile No.</th>
                                        <td>{{ ucfirst($mortgage_details[0]->mobile) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Created At</th>
                                        <td>{{ $mortgage_details[0]->created_at }}</td>
                                    </tr>
                                    <tr>
                                        <th>Updated At</th>
                                        <td>{{ $mortgage_details[0]->updated_at }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('custom_script')

	
@endsection