<div class="left-aside desktop-view">
    <div class="aside-branding">
        <a href="javascript:void(0);" class="iconic-logo logo-text">H<span style="color: #ffffff;">D</span></a>
        <a href="javascript:void(0);" class="large-logo large-logo-text">Houz<span style="color: #ffffff;">Dealz</span></a><span class="aside-pin waves-effect"><i class="fa fa-thumb-tack"></i></span>
        <span class="aside-close waves-effect"><i class="fa fa-times"></i></span>
    </div>
    <div class="left-navigation">
        <ul class="list-accordion">
            <li><a href="javascript:void(0);" class="waves-effect"><span class="nav-icon"><i class="fa fa-home"></i></span><span class="nav-label">Dashboard</span> <span class="label label-primary">New</span></a>
                <!-- <ul>
                    <li><a href="dashboard-01.html">Dashboard - 01</a>
                    </li>
                    <li><a href="dashboard-02.html">Dashboard - 02</a>
                    </li>
                    <li><a href="dashboard-03.html">Dashboard - 03</a>
                    </li>
                </ul> -->
            </li>
            <li><a href="javascript:void(0);" class="waves-effect"><span class="nav-icon"><i class="fa fa-align-justify"></i></span><span class="nav-label">Mortgage Agent</span></a>
                <ul>
                    <li><a href="{{ url('admin/mortgage') }}">List of Agents</a>
                    </li>
                    <li><a href="{{ url('admin/mortgage/create') }}">Add Mortgage Agent</a>
                    </li>
                    <!-- <li><a href="summernote-wysiwyg.html">Summernote WYSIWYG Editor </a>
                    </li>
                    <li><a href="date-picker.html">Date Pickers</a>
                    </li> -->
                </ul>
            </li>
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="fa fa-table"></i></span><span class="nav-label">Realtors</span></a>
                <ul>
                    <li><a href="{{ url('admin/realtor') }}">List of Realtors</a>
                    </li>
                    <li><a href="{{ url('admin/realtor/create') }}">Add Realtors</a>
                    </li>
                    <!-- <li><a href="basic-tables.html">Basic Tables</a>
                    </li>
                    <li><a href="stack-tables.html">Stack Tables</a>
                    </li> -->
                </ul>
            </li>
            <!-- <li><a href="ui-elements-components.html"><span class="nav-icon"><i class="ico-lab"></i></span><span class="nav-label">Inspectors</span></a>
            </li> -->
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="ico-hammer-wrench"></i></span><span class="nav-label">Inspectors</span></a>
                <ul>
                    <li><a href="{{ url('admin/inspector') }}">List of Inspectors</a>
                    </li>
                    <li><a href="{{ url('admin/inspector/create') }}">Add Inspectors</a>
                    </li>
                    <!-- <li><a href="bootstrap-elements.html">Bootstrap Elements</a>
                    </li>
                    <li><a href="grid-portlets.html">Grid Portlets</a>
                    </li> -->
                </ul>
            </li>
            <!-- <li><a href="widgets.html"><span class="nav-icon"><i class="ico-lab"></i></span><span class="nav-label">UI Widgest</span>  <span class="label label-primary">New</span></a>
            </li> -->
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="ico-chart"></i></span><span class="nav-label">Property</span></a>
                <ul>
                    <li><a href="{{ url('admin/property') }}">List of Properties</a>
                    </li>
                    <li><a href="{{ url('admin/property/create') }}">Add Property</a>
                    </li>
                    <!-- <li><a href="easy-pie.html">Easy Pie <span class="label label-primary">New</span></a>
                    </li> -->
                </ul>
            </li>
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="ico-lifebuoy"></i></span><span class="nav-label">Buyers</span></a>
                <ul>
                    <li><a href="{{ url('admin/buyer') }}">List of Buyers</a>
                    </li>
                    <li><a href="{{ url('admin/buyer/create') }}">Add Buyer</a>
                    </li>
                </ul>
            </li>
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="ico-lifebuoy"></i></span><span class="nav-label">Sellers</span></a>
                <ul>
                    <li><a href="{{ url('admin/seller') }}">List of Sellers</a>
                    </li>
                    <li><a href="{{ url('admin/seller/create') }}">Add Seller</a>
                    </li>
                </ul>
            </li>
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="ico-lifebuoy"></i></span><span class="nav-label">Analytics</span></a>
                <ul>
                    <li><a href="{{ url('admin/financial_analytics') }}">Financial Analytics</a>
                    </li>
                    <li><a href="{{ url('admin/other_statistics') }}">Other Statistics</a>
                    </li>
                </ul>
            </li>
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="fa fa-envelope-o"></i></span><span class="nav-label">Blog</span></a>
                <ul>
                    <li><a href="{{ url('admin/blog') }}">List all Blogs</a>
                    </li>
                    <li><a href="{{ url('admin/blog/create') }}">Add Blogs</a>
                    </li>
                </ul>
            </li>
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="ico-lifebuoy"></i></span><span class="nav-label">Search</span></a>
                <ul>
                    <li><a href="javascript:void(0);">On Home Page</a>
                    </li>
                    <li><a href="javascript:void(0);">Other Pages</a>
                    </li>
                </ul>
            </li>
            <li><a href="javascript:void(0);"><span class="nav-icon"><i class="ico-pen"></i></span><span class="nav-label">Pages</span></a>
                <ul>
                    <li><a href="javascript:void(0);">List of Pages</a>
                    </li>
                    <li><a href="javascript:void(0);">Add Page</a>
                    </li>
                </ul>
            </li>
            <!-- <li><a href="javascript:void(0);"><span class="nav-icon"><i class="fa fa-file-text-o"></i></span><span class="nav-label">Extras</span></a>
                <ul>
                    <li><a href="login.html">Login</a>
                    </li>
                    <li><a href="invoice.html">Invoice</a>
                    </li>
                    <li><a href="error-page.html">404 Error</a>
                    </li>
                </ul>
            </li> -->
        </ul>
    </div>
</div>