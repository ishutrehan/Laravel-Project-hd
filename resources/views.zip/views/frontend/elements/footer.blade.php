      <footer class="page-foot page-foot-default section-35 bg-gray-base">
        <div class="shell">
          <div class="range text-center">
            <div class="cell-xs-12">
              <p class="rights small"><span>Houz dealz</span><span>&nbsp;&#169;&nbsp;</span><span id="copyright-year"></span><span>All Rights Reserved</span><br class="veil-sm"><a href="#" class="link-primary-inverse">Terms of Use</a><span>and</span><a href="#" class="link-primary-inverse">Privacy Policy</a>
                <!-- {%FOOTER_LINK}-->
              </p>
            </div>
          </div>
        </div>
      </footer>